For Body

Font = verdana
Left Margin = 210px
Background = #5d9ab2 
Image File = img_tree.png
No-repeat 
Margin = 10px 
Padding = 5px


For .center_div

Border = 1px solid gray
Margin-left = auto
Margin-right = auto
Width = 90%
Height = 340px
Background Color = #d0f0f6
Text Alignment = left
Padding:8px;